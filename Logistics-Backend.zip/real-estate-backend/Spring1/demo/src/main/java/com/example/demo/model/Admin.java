package com.example.demo.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Admin {

    @Id
    private int admin_id;
    private String name;

   //admin to agent
    @OneToMany(mappedBy = "admin",cascade = CascadeType.ALL)
    @JsonManagedReference
    private List<Agent> agent;
    
    
    public Admin() {
    }
    public Admin(int admin_id, String name) {
        this.admin_id = admin_id;
        this.name = name;
    }
    public int getAdmin_id() {
        return admin_id;
    }
    public void setAdmin_id(int admin_id) {
        this.admin_id = admin_id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    
    
}
